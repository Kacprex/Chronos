# Inference utilities (batched GPU inference server)
